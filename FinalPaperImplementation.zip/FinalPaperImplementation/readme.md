# DS340W Final Paper Implementation

This folder contains the **implementation for the final paper**, including:

- Pre-generated dataset: `rg30_set1.csv`
- Code for all experiments (data preprocessing, model training, evaluation, and explainability): `final_code.ipynb`

The code **assumes the data file lives in the same folder** as the script/notebook.

---

## Contents

- `final_code.ipynb`  
  Final implementation code:
  - Loads `rg30_set1.csv`
  - Preprocesses features and labels
  - Trains three ML models:
    - Logistic Regression  
    - Naive Bayes  
    - Random Forest  
  - Compares against two analytical baselines:
    - Early SPI-only rule  
    - Structural (CPM) features using Logistic Regression  
  - Produces evaluation metrics (Accuracy, F1, ROC–AUC), feature importance plots, and SHAP explanations.

- `rg30_set1.csv`  
  Final dataset (one row per project) with:
  - Network structure features (e.g., `n_edges`, `density`, `critical_path_len`, `pct_critical_tasks`)
  - Uncertainty features (e.g., `mean_m`, `mean_range_po`, `instability_m`)
  - Early EVM features (`spi_early`, `cpi_early`)
  - Policy parameters (`buffer_factor`)
  - Diagnostic probability (`p_late_diag`)
  - Binary label (`label_delay`)

---

## ⚠️ Important: Do **Not** Run the Data Generation Block

The code includes a **data generation section** that:

- Reads raw `.rcp` files  
- Builds PERT triplets  
- Runs CPM, Monte Carlo simulation, and EVM  
- Writes a new `rg30_set1.csv`

This block is **for documentation only** and is **not needed** to reproduce the final results.  
Running it also requires the original `.rcp` files (not included here) and is computationally expensive.

**Please:**

- **Do NOT run** the `if __name__ == "__main__":` block that calls:
  - `build_data_rangen(...)`
  - `write_csv(...)`

Instead, use the **provided** `rg30_set1.csv` directly (the rest of the code already does this).

---

## How to Run (Local – VS Code / Any IDE)

1. **Download from GitHub**
   - Download the `FinalPaperImplementation.zip` file.
   - Unzip it (e.g., into `Downloads/FinalPaperImplementation`).

2. **Ensure folder structure**
   - `FinalPaperImplementation/`
     - `final_code.ipynb`
     - `rg30_set1.csv`

3. **Create/activate a Python environment (optional but recommended)**  
   Example using `conda`:
   ```bash
   conda create -n ds340w_final python=3.9
   conda activate ds340w_final

